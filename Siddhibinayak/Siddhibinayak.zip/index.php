<?php include "header.php"; ?>

<section class="welcome py-5">
	<div class="container py-4">
		<div class="row">
			<div class="col-md-8 metro">
				<h2 class="pb-3 welcome-text">WELCOME TO METRON</h2>
				<div class="separator position-relative mb-3"></div>
				<h5 class="py-3 font-weight-bold topic pt-4">Providing Best Indutrial Solution For Our Customers Business Growing In Last 25+ Years.</h5>

				<p class="paragraph">Pleasure and praising pain was born and will give you complete works of the system, and expound the actual teachings of the great explorer of the truth, the mater builder human happiness explain too you this mistaken praising pain was born and will give you a complete account the system, and expound great explorer of the truth, the of human happiness.</p>

				<div class="row py-4">
					<div class="col-md-4">
						<div class="inner-welcome">
							<span><i class="fab fa-jenkins pr-3"></i></span>
							<h1>1.5K</h1>
						</div>
						<h5 class="title">Qualified Engineers</h5>
					</div>
					<div class="col-md-4">
						<div class="inner-welcome">
							<span><i class="fab fa-searchengin pr-3"></i></span>
							<h1>2.3K</h1>
						</div>
						<h5 class="title">Projects Completed</h5>
					</div>
					<div class="col-md-4">
						<div class="inner-welcome">
							<span><i class="fas fa-globe-asia pr-3"></i></span>
							<h1>148+</h1>
						</div>
						<h5 class="title">Branches Worldwide</h5>
					</div>
				</div>
			</div>
			<div class="col-md-4 carousel-col">
				<div id="slideCarousel" class="carousel slide" data-ride="carousel">
					<ul class="carousel-indicators">
						<li class="active" data-target="#slideCarousel" data-slide-to="0"></li>
						<li data-target="#slideCarousel" data-slide-to="1"></li>
						<li data-target="#slideCarousel" data-slide-to="2"></li>
					</ul>
					<div class="carousel-inner">
						<div class="carousel-item active">
							<div class="firstcarousel position-relative">
								<span><i class="fab fa-mixcloud pr-4"></i></span>
								<h5 class="text-uppercase pt-2">Our Mission</h5>
							</div>
							<div class="secondcarousel">
								<p>We work systematically to integrate corporate responsibility in our core business and make our expertise available for the benefit of the to take a trivial example, which of us ever undertakes laborious physical exercise, societies. A small river named Duden flows by their place. It is a paradisematic country.</p>
							</div>
						</div>

						<div class="carousel-item">
							<div class="firstcarousel position-relative">
								<span><i class="fab fa-mixcloud pr-4"></i></span>
								<h5 class="text-uppercase pt-2">Our Goal</h5>
							</div>
							<div class="secondcarousel">
								<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
								tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
								quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
								consequat.</p>
							</div>
						</div>

						<div class="carousel-item">
							<div class="firstcarousel position-relative">
								<span><i class="fab fa-mixcloud pr-4"></i></span>
								<h5 class="text-uppercase pt-2">Our Target</h5>
							</div>
							<div class="secondcarousel">
								<p>We work systematically to integrate corporate responsibility in our core business and make our expertise available for the benefit of the to take a trivial example, which of us ever undertakes laborious physical exercise, societies. A small river named Duden flows by their place. It is a paradisematic country.</p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>

<?php include "footer.php"; ?>